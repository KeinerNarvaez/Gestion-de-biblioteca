-- Insert authors
INSERT INTO authors (name, nationality) VALUES
('J.K. Rowling', 'British'),
('George Orwell', 'British'),
('Harper Lee', 'American');

-- Insert publishers
INSERT INTO publishers (name, country) VALUES
('Bloomsbury', 'UK'),
('Penguin', 'UK'),
('HarperCollins', 'USA');

-- Insert categories
INSERT INTO categories (name) VALUES
('Fiction'),
('Non-Fiction'),
('Mystery');

-- Insert books
INSERT INTO books (title, author_id, publisher_id, category_id, publication_year, total_quantity, available_quantity) VALUES
('Harry Potter and the Philosopher''s Stone', 1, 1, 1, 1997, 10, 10),
('1984', 2, 2, 2, 1949, 5, 5),
('To Kill a Mockingbird', 3, 3, 1, 1960, 8, 8),
('The Great Gatsby', 3, 3, 1, 1925, 6, 6),
('Animal Farm', 2, 2, 2, 1945, 4, 4),
('Pride and Prejudice', 1, 1, 1, 1813, 7, 7);

-- Insert users
INSERT INTO users (name, email, phone, address, status) VALUES
('John Doe', 'john.doe@example.com', '1234567890', '123 Main St', TRUE),
('Jane Smith', 'jane.smith@example.com', '0987654321', '456 Elm St', TRUE),
('Bob Johnson', 'bob.johnson@example.com', '5555555555', '789 Oak St', FALSE);

-- Insert librarians
INSERT INTO librarians (name, email, phone, hire_date) VALUES
('Alice Librarian', 'alice.lib@example.com', '1111111111', '2020-01-01'),
('Charlie Librarian', 'charlie.lib@example.com', '2222222222', '2019-05-15');

-- Insert fines
INSERT INTO fines (user_id, amount, description, paid) VALUES
(3, 5.00, 'Overdue book', FALSE);

-- Insert loans
INSERT INTO loans (user_id, librarian_id, loan_date, return_date, status) VALUES
(1, 1, '2023-10-01', '2023-10-15', 'Returned'),
(2, 2, '2023-10-05', NULL, 'Ongoing');

-- Insert loan details
INSERT INTO loan_details (loan_id, book_id, quantity) VALUES
(1, 1, 1),
(2, 2, 1);

-- Insert reservations
INSERT INTO reservations (user_id, book_id, reservation_date, status) VALUES
(3, 1, '2023-10-10', 'Active');