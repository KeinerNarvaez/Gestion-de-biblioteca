package com.yourorg.library.loans.Entity;

import com.yourorg.library.catalog.Entity.Book;
import jakarta.persistence.*;

@Entity
@Table(name = "loan_details")
public class LoanDetail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "detail_id")
    private Long detailId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "loan_id", nullable = false)
    private Loan loan;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "book_id", nullable = false)
    private Book book;

    @Column(name = "quantity", nullable = false)
    private Integer quantity = 1;

    // Constructors
    public LoanDetail() {}

    public LoanDetail(Loan loan, Book book, Integer quantity) {
        this.loan = loan;
        this.book = book;
        this.quantity = quantity;
    }

    // Getters and Setters
    public Long getDetailId() { return detailId; }
    public void setDetailId(Long detailId) { this.detailId = detailId; }

    public Loan getLoan() { return loan; }
    public void setLoan(Loan loan) { this.loan = loan; }

    public Book getBook() { return book; }
    public void setBook(Book book) { this.book = book; }

    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) { this.quantity = quantity; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LoanDetail loanDetail = (LoanDetail) o;
        return detailId != null && detailId.equals(loanDetail.detailId);
    }

    @Override
    public int hashCode() {
        return getClass().hashCode();
    }
}