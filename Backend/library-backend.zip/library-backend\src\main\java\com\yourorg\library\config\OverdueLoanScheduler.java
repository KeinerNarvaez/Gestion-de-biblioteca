package com.yourorg.library.config;

import com.yourorg.library.loans.Entity.Loan;
import com.yourorg.library.loans.IRepository.LoanRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Component
public class OverdueLoanScheduler {

    private static final Logger logger = LoggerFactory.getLogger(OverdueLoanScheduler.class);

    private final LoanRepository loanRepository;

    public OverdueLoanScheduler(LoanRepository loanRepository) {
        this.loanRepository = loanRepository;
    }

    @Scheduled(cron = "0 0 0 * * ?") // Run daily at midnight
    @Transactional
    public void checkAndUpdateOverdueLoans() {
        logger.info("Checking for overdue loans...");

        LocalDate today = LocalDate.now();
        List<Loan> ongoingLoans = loanRepository.findByStatus("Ongoing");

        for (Loan loan : ongoingLoans) {
            if (loan.getLoanDate().plusDays(14).isBefore(today)) { // Assuming 14 days loan period
                loan.setStatus("Overdue");
                loanRepository.save(loan);
                logger.info("Loan {} marked as overdue", loan.getLoanId());
                // TODO: Send email notification
            }
        }

        logger.info("Overdue loan check completed.");
    }
}