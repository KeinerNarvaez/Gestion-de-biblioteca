# Library Management System Backend

This is a monolithic Spring Boot backend for a Library Management System.

## Features

- User management
- Librarian management
- Book catalog management
- Loan and reservation system
- Fine management
- Scheduled overdue loan checks

## Technologies

- Java 17
- Spring Boot 3.x
- Spring Data JPA
- PostgreSQL
- H2 (for testing)
- Flyway
- MapStruct
- Docker

## Getting Started

### Prerequisites

- Java 17
- Maven
- Docker (optional)

### Running with Maven

1. Clone the repository
2. Navigate to the project directory
3. Run `mvn clean install`
4. Run `mvn spring-boot:run`

For development (H2): Set `spring.profiles.active=dev`

For production (PostgreSQL): Set `spring.profiles.active=prod` and configure database properties.

### Running with Docker

1. Build the JAR: `mvn clean package`
2. Run `docker-compose up`

## API Endpoints

### Users
- GET /api/users - Get all users
- GET /api/users/{id} - Get user by ID
- POST /api/users - Create user
- PUT /api/users/{id} - Update user
- DELETE /api/users/{id} - Delete user

### Books
- GET /api/books - Get all books
- GET /api/books/{id} - Get book by ID
- POST /api/books - Create book
- PUT /api/books/{id} - Update book
- DELETE /api/books/{id} - Delete book
- GET /api/books/search?title=&author=&category= - Search books

### Loans
- GET /api/loans - Get all loans
- GET /api/loans/{id} - Get loan by ID
- POST /api/loans/create - Create loan
- PUT /api/loans/{id}/return - Return loan

### Reservations
- GET /api/reservations - Get all reservations
- POST /api/reservations/create - Create reservation
- PUT /api/reservations/{id}/cancel - Cancel reservation

### Fines
- GET /api/fines - Get all fines
- PUT /api/fines/{id}/pay - Pay fine

## Sample Requests

### Create User
```bash
curl -X POST http://localhost:8080/api/users \
  -H "Content-Type: application/json" \
  -d '{
    "name": "John Doe",
    "email": "john.doe@example.com",
    "phone": "1234567890",
    "address": "123 Main St"
  }'
```

### Create Book
```bash
curl -X POST http://localhost:8080/api/books \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Sample Book",
    "authorId": 1,
    "publisherId": 1,
    "categoryId": 1,
    "publicationYear": 2023,
    "totalQuantity": 10,
    "availableQuantity": 10
  }'
```

### Create Loan
```bash
curl -X POST http://localhost:8080/api/loans/create \
  -H "Content-Type: application/json" \
  -d '{
    "userId": 1,
    "librarianId": 1,
    "bookIds": [1, 2]
  }'
```

### Return Loan
```bash
curl -X PUT http://localhost:8080/api/loans/1/return
```

## Database Schema

The database schema includes tables for users, librarians, authors, publishers, categories, books, loans, loan_details, reservations, and fines.

## Testing

Run tests with `mvn test`

## Project Structure

```
src/main/java/com/yourorg/library/
├── LibraryApplication.java
├── config/
├── exception/
├── users/
│   ├── Controller/
│   ├── DTO/
│   ├── Entity/
│   ├── IRepository/
│   ├── IService/
│   └── Service/
├── catalog/
│   ├── Controller/
│   ├── DTO/
│   ├── Entity/
│   ├── IRepository/
│   ├── IService/
│   └── Service/
├── loans/
│   ├── Controller/
│   ├── DTO/
│   ├── Entity/
│   ├── IRepository/
│   ├── IService/
│   └── Service/
└── common/
```

## Notes

- Since the FlightManagementSystem.zip could not be accessed, a fallback structure was used based on the provided requirements.
- The project uses a layered architecture with separate packages for each module.
- Business logic is implemented in service layers with proper transaction management.
- Global exception handling is in place for consistent error responses.